from BaseDatas.Config import *
from datetime import datetime
# moves
from Classes.ChildClasses.ArmyType.Vanguard import vanguard
from Classes.ChildClasses.ArmyType.SpellWeavers import spellweavers
from Classes.ChildClasses.ArmyType.ShadowCorpse import shadowcorpse

from Classes.ChildClasses.LandType.Plain import plain
from Classes.ChildClasses.LandType.Mountain import mountain
from Classes.ChildClasses.LandType.Desert import desert

import os
import sys
import time

#======================Assets==================
# clear screen
def clear():
   os.system("cls" if os.name == "nt" else "clear")
   
# animated typing
def speak(text, delay = 0.03):
  for char in text:
    sys.stdout.write(char)
    sys.stdout.flush()
    time.sleep(delay)
    
  print()
  
# animated border
def draw_border(title = "INFO"):
  width = 45
  
  print(CYAN + "+" + "-" * width + "+" + RESET)
  for i in range(3):
    if i == 1:
      pad = (width - len(title)) // 2
      
      print(CYAN + "|" + " " * pad + BOLD + title + RESET + CYAN + " " * (width - len(title) - pad) + "|" + RESET)
    else:
      print(CYAN + "|" + " " * width + "|" + RESET)
      
    time.sleep(0.05)
  print(CYAN + "+" + "-" * width + "+" + RESET)
  
  
def create_character(data_manager, username: str, biome: str, choice: str):
  """create_character - returns created character"""
  
  character_class = {
    "1": shadowcorpse,
    "2": spellweavers,
    "3": vanguard
  }
  
  return character_class[choice](data_manager, username, biome)
  
def load_character(data_manager, username, biome):
  """load_character - returns stored character"""
  
  data = data_manager.load()
  
  character_class = data[username]["army_ty"]
  
  character_map = {
    "shadowcorpse": shadowcorpse,
    "spellweavers": spellweavers,
    "vanguard": vanguard
  }
  
  return character_map[character_class](data_manager, username, biome)
  
def create_biome(data_manager, username: str, army_ty:str, choice: str):
  """create_biome - returns created biome"""
  
  biome_class = {
    "1": plain,
    "2": desert,
    "3": mountain
  }
  
  return biome_class[choice](data_manager, username, army_ty)
  
def load_biome(data_manager, username, army_ty):
  """load_biome - returns stored biome"""
  
  data = data_manager.load()
  
  biome_class = data[username]["biome"]
  
  biome_map = {
    "plain": plain,
    "desert": desert,
    "mountain": mountain
  }
  
  return biome_map[biome_class](data_manager, username, army_ty)
  
  

# dialogues for show info feature  
dialogues = [
  "Quite a lazy day to see info",
  "Work hard for the kingdom, Info:",
  "Peoples should care about King who check info evrytime",
  "Ahhhh! Here is the info:"
  ]
  
# dialogues for viewing land feature
dialogues_view_land = [
  "Ah greetings my king, I am Land Viewer and here is the current view of our lands.",
  "Greetings Your Majesty, Land Viewer at your service with the latest land overview.",
  "Ah my king, I have surveyed the lands and bring you the full report.",
  "Welcome great king, Land Viewer here with the status of our territory.",
  "Greetings my lord, I am Land Viewer and I present to you the view of our realm."
  ]
  
dialogues_buy_land = [
  "Ah greetings my king, shall I arrange the purchase of more land for our realm?",
  "Greetings Your Majesty, Land Viewer here—would you like to buy additional territory?",
  "My lord, I can help you acquire new land if you wish to expand our domain.",
  "Ah my king, Land Viewer at your service. Ready to buy more land for our people?",
  "Greetings great king, I have found suitable land available for purchase."
  ]
  
dialogues_food_shop = [
    "Welcome traveler... take a look at my wares.",
    "Best prices in the kingdom, I swear it!",
    "Careful... some items are rare.",
    "You look strong... maybe you need some foods for your kingdom?"
  ]
  
dialogues_resource_market = [
    "Ah greetings my king, welcome to the resource selling market.",
    "Greetings Your Majesty, I am the market trader ready to buy your resources.",
    "My lord, welcome to the resource market—shall we sell some goods?",
    "Ah my king, the resource selling market is open for your trade.,"
    "Greetings great king, I handle resource sales here at the market."
    ]
    

enemy_country = {
  "1": {
    "name": "Heart Kingdom",
    "atk": 40,
    "hp": 100,
    "max_hp": 100,
    "st": 100,
    "max_st": 100
  },
  "2": {
    "name": "Spade Kingdom",
    "atk": 80,
    "hp": 180,
    "max_hp": 180,
    "st": 110,
    "max_st": 110
  },
  "3": {
    "name": "Clover Kindom",
    "atk": 120,
    "hp": 120,
    "max_hp": 120,
    "st": 300,
    "max_st": 300
  }
}

dungeon_dict = {
  "1": {
    "name": "Snail cave army",
    "atk": 30,
    "hp": 100,
    "st": 100,
    "max_hp": 100,
    "max_st": 100
  },
  
  "2": {
    "name": "Toad mountain army",
    "atk": 50,
    "hp": 120,
    "st": 120,
    "max_hp": 120,
    "max_st": 120
  },
  
  "3": {
    "name": "Snake cave army",
    "atk": 80,
    "hp": 180,
    "st": 180,
    "max_hp": 180,
    "max_st": 180
  }
}



def hp_bar(current, max_hp, length=20):
  filled = int((current / max_hp) * length)
  bar = "█" * filled + "-" * (length - filled)
  return f"[{bar}] {current}/{max_hp}"
  
def st_bar(current, max_st, length=20):
  filled = int((current / max_st) * length)
  bar = "█" * filled + "-" * (length - filled)
  return f"[{bar}] {current}/{max_st}"
  

def render(player, enemy_choice, d_k, player_dict = None):
    clear()
    
    global enemy
      
    print(BOLD + CYAN + "=== ⚔️  RPG BATTLE SCREEN ===" + RESET)
    print()
    
    if player_dict is None:
      player_dict = {
        "hp": player.army_hp,
        "atk": player.army_atk,
        "st": player.army_st,
        "max_hp": player.army_hp,
        "max_st": player.army_st
      }

    # Player panel
    print(BLUE + f"🧙 {player.name}" + RESET)
    print("HP:", GREEN + hp_bar(player_dict["hp"], player_dict["max_hp"]) + RESET)
    print("ST:", GREEN + st_bar(player_dict["st"], player_dict["max_st"]) + RESET)
    print(f"ATK: {player_dict['atk']}")
    print()

    # Enemy panel
    if d_k == "kingdom":
      enemy = enemy_country[enemy_choice]
    else:
      enemy = dungeon_dict[enemy_choice]
  
    print(RED + f"👹 {enemy['name']}" + RESET)
    print("HP:", YELLOW + hp_bar(enemy["hp"], enemy["max_hp"]) + RESET)
    print("ST:", YELLOW + hp_bar(enemy["st"], enemy["max_st"]) + RESET)
    print(f"ATK: {enemy['atk']}")
    print()

    print(CYAN + "-----------------------------" + RESET)
    if player.army_ty == "spellweavers":
      print("fireball    nano_shield   overcharge_blast")
    elif player.army_ty == "vanguard":
      print("strike    iron_defense   second_wind")
    elif player.army_ty == "shadowcorpse":
      print("shadow_slash   shadow_siphon   shadow_soul")
    print(CYAN + "-----------------------------" + RESET)
    
    return enemy, player_dict




def move_executer(move_name, player_main):
  """move_executer - executes armies moves"""
  
  if player_main.army_ty == "vanguard":
    move_registry = {
      "strike": player_main.strike,
      "iron_defense": player_main.iron_defense,
      "second_wind": player_main.second_wind
    }
    
  elif player_main.army_ty == "spellweavers":
    move_registry = {
      "fireball": player_main.fireball,
      "nano_shield": player_main.nano_shield,
      "overcharge_blast": player_main.overcharge_blast
    }
    
  elif player_main.army_ty == "shadowcorpse":
    move_registry = {
      "shadow_slash": player_main.shadow_slash,
      "shadow_siphon": player_main.shadow_siphon,
      "shadow_soul": player_main.shadow_soul
    }
  
  if move_name not in move_registry:
    print(f"{RED_BG}No such move{RESET}")
    return
  
  move_func = move_registry[move_name]
  
  return move_func()