# =================================================
#           **KINGDOM SKYLINES(GAME)**
# =================================================

# ====================IMPORTS======================

import os
import sys
import json
import time
import random
from typing import Dict, Any, Optional

# =====================COLORS=====================

BLACK   = "\033[30m"
RED     = "\033[31m"
GREEN   = "\033[32m"
YELLOW  = "\033[33m"
PURPLE = "\033[1;35m"
BLUE    = "\033[34m"
MAGENTA = "\033[35m"
CYAN    = "\033[36m"
WHITE   = "\033[37m"
RESET   = "\033[0m"
BOLD = "\033[1m"

BG_BLACK   = "\033[40m"
BG_RED     = "\033[41m"
BG_GREEN   = "\033[42m"
BG_YELLOW  = "\033[43m"
BG_BLUE    = "\033[44m"
BG_MAGENTA = "\033[45m"
BG_CYAN    = "\033[46m"
BG_WHITE   = "\033[47m"

# =====================PATH======================

FILE_PATH = "/storage/emulated/0/Python learning/things made by Siddharth/KingdomSkylines/PlayerDatas/KingdomData.txt"

# ===============================================
#                END OF CONFIG
# ===============================================