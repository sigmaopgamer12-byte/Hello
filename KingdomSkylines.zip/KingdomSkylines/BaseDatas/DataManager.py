from BaseDatas.Config import *
from datetime import datetime
# =================DATA MANAGER==================

class DataManager:
  """DataManager - manages all the datas"""
  
  def __init__(self, file_path: str = FILE_PATH):
    self.file_path = file_path
    
  def load(self):
    """load - loads datas from the file"""
    
    if os.path.exists(self.file_path):
      try:
        with open(self.file_path, "r") as file:
          content = file.read()
          data = json.loads(content) if content else {}
          for key in data:
            if "tax_time" in data[key]:
                data[key]["tax_time"] = datetime.fromisoformat(data[key]["tax_time"])
          return data
      except:
        return {}
    return {}
    
  def save(self, data: Dict[str, Any]) -> None:
    """save - saves datas to the file"""
    
    with open(self.file_path, "w", encoding = "utf-8") as file:
      json.dump(data, file, indent=4, default=lambda obj: obj.isoformat() if isinstance(obj, datetime) else str(obj))
      
# =============================================
#            End of DataManager
# =============================================