from BaseDatas.Config import *
from Classes.Kingdom import *
import random

# ==========================CHILD CLASS 4=================================

class shadowcorpse(kingdom):
  """shadowcorpse - gives base stats to the shadowcorps"""
  
  def __init__(self, data_manager: DataManager, name: str, biome: str):
    super().__init__(data_manager, name, biome, "shadowcorpse")
    
    if self.is_new:
      self.army_atk -= 5
      self.army_hp -= 10
      self.army_st += 35
      
      self.save_data()
      
  def shadow_slash(self):
    """shadowslash -  a basic m1 atk"""
    bonus_atk = ((15/100) * self.army_atk)
    self.army_atk += bonus_atk
    self.army_st -= 15
    return int(self.army_atk), int(self.army_hp), int(self.army_st)
    
  def shadow_siphon(self):
    """shadow_siphon - sucks 10% of attack and gives 15% health"""
    
    sacrificed_atk = ((10/100) * self.army_atk)
    self.army_atk -= sacrificed_atk
    boosted_hp = ((15/100) * self.army_hp)
    self.army_hp += boosted_hp
    self.army_st -= 20
    
    return int(self.army_atk), int(self.army_hp), int(self.army_st)
  
  def shadow_soul(self):
    """overcharge_blast - gambles for 25% chance shadowsoul"""
    move_chance = random.choice(["yes", "no", "no"])
    
    if move_chance == "yes":
      self.army_atk *= 3
      self.army_st -= 50
      
    return int(self.army_atk), int(self.army_hp), int(self.army_st)
# ==================================END======================================