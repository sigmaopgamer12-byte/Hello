from BaseDatas.Config import *
from Classes.Kingdom import *

# ==========================CHILD CLASS 4=================================

class spellweavers(kingdom):
  """spellweavers - gives base stats to the spellweavers"""
  
  def __init__(self, data_manager: DataManager, name: str, biome: str):
    super().__init__(data_manager, name, biome, "spellweavers")
    
    if self.is_new:
      self.army_atk += 15
      self.army_hp -= 40
      self.army_st += 25
      
      self.save_data()
      
  def fireball(self):
    """fireball -  a basic m1 atk"""
    bonus_atk = ((10/100) * self.army_atk)
    self.army_atk += bonus_atk
    self.army_st -= 10
    return int(self.army_atk), int(self.army_hp), int(self.army_st)
    
  def nano_shield(self):
    """nano_shield - gives max health with extra 15% health"""
    
    sacrificed_st = ((10/100) * self.army_st)
    self.army_st -= sacrificed_st
    boosted_hp = ((15/100) * self.army_hp)
    self.army_hp += boosted_hp
    
    return int(self.army_atk), int(self.army_hp), int(self.army_st)
  
  def overcharge_blast(self):
    """overcharge_blast - increases atk by 50%"""
    
    boosted_atk = ((50/100) * self.army_atk)
    self.army_atk += boosted_atk
    self.army_st -= 40
    
    return int(self.army_atk), int(self.army_hp), int(self.army_st)
# ==================================END======================================