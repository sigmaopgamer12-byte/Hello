from BaseDatas.Config import *
from Classes.Kingdom import *

# ==========================CHILD CLASS 4=================================

class vanguard(kingdom):
  """vanguard - gives base stats to the vanguard"""
  
  def __init__(self, data_manager: DataManager, name: str, biome: str):
    super().__init__(data_manager, name, biome, "vanguard")
    
    if self.is_new:
      self.army_hp += 40
      self.army_st -= 20
      
      self.save_data()
      
  def strike(self):
    """strike -  a basic m1 atk"""
    self.army_st -= 10
    
    return int(self.army_atk), int(self.army_hp), int(self.army_st)
    
  def iron_defense(self):
    """iron_defense - multiplies hp by 1.5"""
    self.army_hp *= 1.5
    self.army_st -= 20
    return int(self.army_atk), int(self.army_hp), int(self.army_st)
    
  def second_wind(self):
    """second_wind - does 1.5x greater dmg"""
    self.army_atk *= 1.5
      
    return int(self.army_atk), int(self.army_hp), int(self.army_st)
      
# ==================================END======================================