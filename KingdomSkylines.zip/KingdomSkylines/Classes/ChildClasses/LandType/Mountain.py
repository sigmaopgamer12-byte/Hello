from Classes.Kingdom import *
from BaseDatas.Config import *

# ==============================CHILD CLASS 3===================================

class mountain(kingdom):
  """mountain - child class 1"""
  
  def __init__(self, data_manager: DataManager, name:str, army_ty: str):
    super().__init__(data_manager, name, "mountain", army_ty)
    
    if self.is_new:
      self.food -= 60
      self.gold += 25
      self.iron +=80
      self.land_capacity += 350
      self.save_data()
    
  def disaster(self, occurence):
    if not occurence:
      return
    
    print(f"{BG_RED}Due to heavy snow!!!, A massive avlanche has occured in your kingdom{RESET}")
    
    # food
    calamity_food_loss = int((10/100) * self.food)
    self.food = int(self.food - calamity_food_loss)
    
    # gold
    calamity_gold_loss = int((2/100) * self.gold)
    self.gold = int(self.gold - calamity_gold_loss)
    
    # iron
    calamity_iron_loss = int((5/100) * self.iron)
    self.iron = int(self.iron - calamity_iron_loss)
    
    # happiness
    self.happiness -= 100
    
    print(f"{BG_RED}Due to massive avlanche, LOST:\n10% food, 2% gold, 5% iron and 100 happiness{RESET}")
    
    self.save_data()
    
# ===================================END======================================