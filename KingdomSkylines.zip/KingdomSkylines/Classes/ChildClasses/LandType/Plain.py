from Classes.Kingdom import *
from BaseDatas.Config import *

# ==============================CHILD CLASS 1===================================

class plain(kingdom):
  """plain - child class 1"""
  
  def __init__(self, data_manager: DataManager, name:str, army_ty: str):
    super().__init__(data_manager, name, "plain", army_ty)
    
    if self.is_new:
      self.food += 100
      self.gold -= 40
      self.iron += 25
      self.land_capacity += 600
      self.save_data()
    
  def disaster(self, occurence):
    if not occurence:
      return
    
    print(f"{BG_RED}Due to heavy rain!!!, A massive flood has occured in your kingdom{RESET}")
    
    # food
    calamity_food_loss = int((10/100) * self.food)
    self.food = int(self.food - calamity_food_loss)
    
    # gold
    calamity_gold_loss = int((10/100) * self.gold)
    self.gold = int(self.gold - calamity_gold_loss)
    
    # iron
    calamity_iron_loss = int((10/100) * self.iron)
    self.iron = int(self.iron - calamity_iron_loss)
    
    # happiness
    self.happiness -= 100
    
    print(f"{BG_RED}Due to heavy flood, LOST:\n10% food, gold and iron and 100 happiness{RESET}")
    
    self.save_data()
    
# ===================================END======================================