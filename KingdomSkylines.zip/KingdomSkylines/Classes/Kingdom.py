from BaseDatas.DataManager import DataManager
from BaseDatas.Config import *
from datetime import datetime
import time

# ===================PARENT CLASS==================
class kingdom:
  """kingdom - Parent class 1"""
  
  def __init__(self, data_manager: DataManager, name: str, biome: str, army_ty: str):
    # base stats
    self.data_manager = data_manager
    self.name = name
    self.biome = biome
    self.army_ty = army_ty
    # default stats
    self.happiness = 0
    self.population = 100
    self.army = 10
    self.food = 100
    self.tax = 10
    self.day = 1
    self.gdp = 50
    self.army_atk = 20
    self.army_hp = 100
    self.army_st = 100
    self.gold = 50
    self.iron = 50
    self.land_capacity = 100
    self.army_pn = self.army_atk * self.army_hp * self.army_st
    self.tax_time = datetime.now()
    
    self.load_data()
    
  def load_data(self):
    """load_data - loads player data to the file"""
    
    data = self.data_manager.load()
    
    if self.name in data:
      pd = data[self.name]
      file_biome = pd.get("biome", "None")
      file_army = pd.get("army_ty", "None")
      
      if file_biome != "None":
        self.biome = file_biome
        
      if file_army != "None":
        self.army_ty = file_army
          
      self.happiness = pd.get("happiness", 0)
      self.population = pd.get("population", 100)
      self.army = pd.get("army", 10)
      self.food = pd.get("food", 100)
      self.tax = pd.get("tax", 10)
      self.day = pd.get("day", 1)
      self.gdp = pd.get("gdp", 50)
      self.army_atk = pd.get("army_atk", 20)
      self.army_hp = pd.get("army_hp", 100)
      self.army_st = pd.get("army_st", 100)
      self.gold = pd.get("gold", 50)
      self.iron = pd.get("iron", 50)
      self.land_capacity = pd.get("land_capacity", 100)
      self.army_pn = pd.get("army_pn", (20 * 100 * 100))
      self.tax_time = pd.get("tax_time", datetime.now())
      
      # new or old check
      if file_biome == "None":
        self.is_new = True
      else:
        self.is_new = False
    
    else:
      self.is_new = True
      
  def save_data(self):
    """save_data - saves player data to the file"""
    
    data = self.data_manager.load()
    
    data[self.name] = {
      "biome": self.biome,
      "happiness": self.happiness,
      "population": self.population,
      "army_ty": self.army_ty,
      "army": self.army,
      "food": self.food,
      "tax": self.tax,
      "day": self.day,
      "gdp": self.gdp,
      "army_atk": self.army_atk,
      "army_hp": self.army_hp,
      "army_st": self.army_st,
      "gold": self.gold,
      "iron": self.iron,
      "land_capacity": self.land_capacity,
      "army_pn": self.army_pn,
      "tax_time": self.tax_time
    }
    
    self.data_manager.save(data)
    
  def disaster(self, occurence: str = False):
    """disaster - made to over-write it in child classes"""
    pass
  
  def level_up(self):
    """level_up - handles kingdom's level up"""
    
    while self.happiness >= 100:
      self.happiness -= 100
      
      # land capacity check
      if self.land_capacity == self.population:
        print(f"{PURPLE}Your land cant contain any more people{RESET}")
      elif self.land_capacity != self.population:
        self.population += 40
      
      self.army += 10
      self.army_atk += 5
      self.army_st += 10
      self.army_hp += 10
      
      print(f"{BG_GREEN}Happiness by passed 100 and because of your hardwork your kingdom got additional:\n+ 40 population\n+ 10 army\n + 5 army attack\n + 10 army attack and army stamina each{RESET}")
    
    self.save_data()