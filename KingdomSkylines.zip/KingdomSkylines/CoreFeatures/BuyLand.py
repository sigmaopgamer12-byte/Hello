from BaseDatas.Config import *
from BaseDatas.Assets import *
import random
# ==================================BUY LAND==================================

def buy_land(player):
  """buy_land - controls buy land feature"""
  
  clear()
  
  db = dialogues_buy_land
  
  draw_border("BUY LAND")
  
  print()
  
  dialog_buy_land = random.choice(db)
  
  speak("Land's man: " + GREEN + dialog_buy_land + RESET)
  
  print()
  
  print(CYAN + "-" * 45 + RESET)
  
  print(f"{BOLD}{YELLOW}Land one: +100 capacity | cost: 500")
  print(f"Land two: +500 capacity | cost: 1500")
  print(f"Land three: + 1000 capacity | cost 2500")
  print(f"Land four: +2000 capacity | cost: 3500{RESET}")
  
  while True:
    buy_land_choice = input("Enter your choice(1-4): ")
    if buy_land_choice in ["1", "2", "3","4"]:
      break
  
  money_dict = {"1": 500, "2": 1500, "3": 2500, "4": 3500}
  capacity_dict = {"1": 100, "2": 200, "3": 1000, "4": 2000}
  
  if money_dict[buy_land_choice] <= player.gdp:
    player.land_capacity += capacity_dict[buy_land_choice]
    player.gdp -= money_dict[buy_land_choice]
    print(f"{BG_GREEN}Successfully bought land and capacity added to your kingdom{RESET}")
    player.save_data()
    
  else:
    print(f"{BG_RED}Insufficient money to buy land{RESET}")
    
  print(CYAN + "-" * 45 + RESET)
  
# =======================================END===============================