from BaseDatas.Config import *
from BaseDatas.Assets import *

# =============================COLLECT TAX==============================

def collect_tax(player):

  passed_time = (datetime.now() - player.tax_time).total_seconds()
  
  if passed_time >= 86400:
    while passed_time >= 86400:
      passed_time -= 86400
      player.gdp += (player.tax * player.population)
      print(f"{BG_GREEN}Gained a total tax of {player.tax * player.population} of 1 day{RESET}")
      
    player.tax_time = datetime.now()
    player.save_data()
  
  else:
    print(f"{RED}It hasnt been one day since you claimed tax{RESET}")
  
# ===============================END============================