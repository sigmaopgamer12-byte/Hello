from BaseDatas.Config import *
from BaseDatas.Assets import *
from BaseDatas.Assets import render, move_executer

# ===============================COUNTRY WAR================================
def country_war(player):
  print(f"{YELLOW}===================KINGOMS==================={RESET}")
  print(f"{PURPLE}1) Heart Kingdom")
  print("2) Spade Kingdom")
  print(f"3) Clover Kingdom{RESET}")
  
  while True:
    enemy_selection = input("Whom do you want to fight?{1 - 3}: ").strip()
    if enemy_selection in ["1", "2", "3"]:
      print(f"{BG_RED}Your army has started forwarding to the enemy's kingdom{RESET}")
      break
    else:
      print(f"{RED}Please choose the country to attack between 1 - 3: {RESET}")
  
  player_dict = {
    "hp": player.army_hp,
    "atk": player.army_atk,
    "st": player.army_st,
    "max_hp": player.army_hp,
    "max_st": player.army_st
    }    
  
  while True:
    d_or_k = "kingdom"
    enemy, player_dict = render(player, enemy_selection, d_or_k, player_dict)
    
    choice_move = input("Execute move:  ").strip().lower()
    
    moves_list = ["strike", "iron_defense", "second_wind", "fireball", "nano_shield", "overcharge_blast", "shadow_soul", "shadow_siphon", "shadow_slash"]
    
    if choice_move in moves_list:
      new_atk, new_hp, new_st = move_executer(choice_move, player)
      
      if choice_move in ["iron_defense", "nano_shield", "shadow_siphon"]:
        player_dict["hp"] = new_hp
      
      enemy["hp"] -= new_atk
      print(f"\n{BG_RED}You hit the {enemy['name']} army!{RESET}")
    else:
      print(f"{PURPLE}Invalid move!!{RESET}")
      
    if enemy["hp"] > 0:
      player_dict["hp"] -= enemy["atk"]
      enemy["st"] -= 15
      print(f"{BG_BLUE}The {enemy['name']} army hit you!{RESET}")
      
    time.sleep(1.2)
    
    if enemy["hp"] <= 0 or enemy["st"] <= 0:
      print(f"{BG_GREEN}You defeated the {enemy['name']}!!!{RESET}")
      if enemy_selection == "1":
        player.food += 30
        player.gdp += 50
        player.gold += 30
        player.iron += 30
        player.land_capacity += 15
        player.save_data()
        print(f"{GREEN}LOOT: + 30 food, gold, iron\n+ 50 GDP\n+ 15 land capacity{RESET}")
        
      elif enemy_selection == "2":
        player.food += 55
        player.gdp += 100
        player.gold += 55
        player.iron += 55
        player.land_capacity += 25
        player.save_data()
        print(f"{GREEN}LOOT: + 55 food, gold, iron\n+ 100 GDP\n+ 25 land capacity{RESET}")
        
      elif enemy_selection == "3":
        player.food += 80
        player.gdp += 200
        player.gold += 80
        player.iron += 80
        player.land_capacity += 40
        player.save_data()
        print(f"{GREEN}LOOT: + 80 food, gold, iron\n+ 200 GDP\n+ 40 land capacity{RESET}")
        
      break
    
    if player_dict["hp"] <= 0:
      print(f"{BG_RED}The {enemy['name']} defeated your kingdom!!!!{RESET}")
      break
    
    print("\nPress enter to continue.....")