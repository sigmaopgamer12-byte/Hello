from BaseDatas.Config import *
from BaseDatas.Assets import *
from BaseDatas.Assets import render, move_executer

# ===============================DUNGEON================================
def dungeon_system(player):
  print(f"{YELLOW}===================KINGOMS==================={RESET}")
  print(f"{PURPLE}1) Snail land")
  print("2) Toad mountain")
  print(f"3) Snake cave{RESET}")
  
  # multiplier
  multiplier = 5
  
  while True:
    enemy_selection = input("Which dungeon do you want to face?(1-3): ").strip()
    if enemy_selection in ["1", "2", "3"]:
      print(f"{BG_RED}Your army has started forwarding to the enemy{RESET}")
      break
    else:
      print(f"{RED}Please choose the country to attack between 1 - 3: {RESET}")
  
  player_dict = {
    "hp": player.army_hp,
    "atk": player.army_atk,
    "st": player.army_st,
    "max_hp": player.army_hp,
    "max_st": player.army_st
    }    

  while True:
    
    
    
    d_or_k = "dungeon"
    enemy, player_dict = render(player, enemy_selection, d_or_k, player_dict)
    
    choice_move = input("Execute move:  ").strip().lower()
    

    
    moves_list = ["strike", "iron_defense", "second_wind", "fireball", "nano_shield", "overcharge_blast", "shadow_soul", "shadow_siphon", "shadow_slash"]
    
    if choice_move in moves_list:
      new_atk, new_hp, new_st = move_executer(choice_move, player)
      player_dict["st"] = new_st
      
      if choice_move in ["iron_defense", "nano_shield", "shadow_siphon"]:
        player_dict["hp"] = new_hp
      enemy["hp"] -= new_atk
      print(f"\n{BG_RED}You hit the {enemy['name']} army!{RESET}")
    else:
      print(f"{PURPLE}Invalid move!!{RESET}")
      
    if enemy["hp"] > 0:
      player_dict["hp"] -= enemy["atk"]
      enemy["st"] -= 15
      print(f"{BG_BLUE}The {enemy['name']} army hit you!{RESET}")
      
    time.sleep(1.2)
    
    if enemy["hp"] <= 0 or enemy["st"] <= 0:
      print(f"{BG_GREEN}You defeated the first wave!!!{RESET}")
      if enemy_selection == "1":
        player.food += 1
        player.gdp += 5
        player.gold += 1
        player.iron += 1
        player.save_data()
        print(f"{GREEN}LOOT: + 1 food, gold, iron\n+ 5 GDP{RESET}")
        
        time.sleep(5)
        
      elif enemy_selection == "2":
        player.food += 10
        player.gdp += 20
        player.gold += 10
        player.iron += 10
        player.save_data()
        print(f"{GREEN}LOOT: + 10 food, gold, iron\n+ 20 GDP{RESET}")
        time.sleep(5)
        
      elif enemy_selection == "3":
        player.food += 25
        player.gdp += 50
        player.gold += 25
        player.iron += 25
        player.save_data()
        print(f"{GREEN}LOOT: + 25 food, gold, iron\n+ 50 GDP\{RESET}")
        time.sleep(5)
        
      # next wave
      enemy["hp"] = enemy["max_hp"] + multiplier
      enemy["atk"] = enemy["atk"] + multiplier
      enemy["st"] = enemy["max_st"] + multiplier
        
      multiplier += 5
        
      print(f"{YELLOW}Next wave of enemy is forwarding!!!!{RESET}")
      time.sleep(5)
        
    
    if player_dict["hp"] <= 0:
      print(f"{BG_RED}The {enemy['name']} defeated your kingdom!!!!{RESET}")
      break
    
    print("\nPress enter to continue.....")