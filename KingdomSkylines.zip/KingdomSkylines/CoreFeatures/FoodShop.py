from BaseDatas.Config import *
from BaseDatas.Assets import *

# ================================FOOD SHOP=================================

def food_shop(player):
  """food_shop - manages food shop logic"""
  
  clear()
  
  df = dialogues_food_shop
  
  draw_border("FOOD SHOP")
  
  print()
  
  diallog_food_shop = random.choice([df[0], df[1], df[2], df[3]])
  
  speak("Food's man:" + GREEN + diallog_food_shop + RESET)
  
  print()
  
  print(CYAN + "-" * 45 + RESET)
  
  fi = {"1": 100, "2": 200, "3": 500, "4": 600, "5": 1000}
  
  fm = {"1": 300, "2": 500, "3": 1000, "4": 3000, "5": 5000}
  
  print(f"{BOLD}{BG_YELLOW}Common food package: +{fi["1"]} food | cost: {fm["1"]}")
  print(f"Uncommon food package: +{fi["2"]} food | cost: {fm["2"]}")
  print(f"Rare food package: +{fi["3"]} food | cost: {fm["3"]}")
  print(f"Legendary food package: +{fi["4"]} food | cost: {fm["4"]}")
  print(f"Mythical food package: +{fi["5"]} food | cost: {fm["5"]}{RESET}")
  
  while True:
    food_choice = input(f"{PURPLE}Enter your choice (1-5){RESET}: ")
    
    if food_choice in ["1", "2", "3", "4", "5"]:
      break
    
  if fm[food_choice] <= player.gdp:
    player.food += fi[food_choice]
    player.gdp -= fm[food_choice]
    
    print(f"{BG_GREEN}Successfully bought food and transported it to your kingdom{RESET}")
    
    player.save_data()
    
  else:
    print(f"{BG_RED}Insufficient money{RESET}")
    
# ===================================END=================================