from BaseDatas.Config import *

# ================================MOTIVATE ARMY=================================

def motivate_army(player):
  """motivate_army - works on motivate army feature"""
  
  speech = input(f"{PURPLE}Type your speech to motivate army: {RESET}").strip().lower()
  
  char_num = 0
  
  for char in speech:
    char_num += 1
  
  if char_num >= 150:
    char_percent = int(((5/100) * char_num))
    player.army_atk += char_percent
    player.army_hp += char_percent
    player.army_st += char_percent
    
    player.save_data()
    
# ========================================END==================================