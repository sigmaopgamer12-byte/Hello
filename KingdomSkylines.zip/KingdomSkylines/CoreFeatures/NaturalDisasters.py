from BaseDatas.Config import *
import random

# ===============================NATURAL DISASATER============================

def disaster_roll():
  if random.randint(1, 101) == 2:
    return True
  
  else:
    return False