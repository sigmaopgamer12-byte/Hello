from BaseDatas.Assets import *
from BaseDatas.Config import *

# =================================PROFILE SHOW=================================

def profile_show(player):
  clear()
  
  draw_border("KINGDOM INFO")
  
  print()
  
  dialog = random.choice([dialogues[0], dialogues[1], dialogues[2], dialogues[3]])
  
  speak("Info: " + GREEN + dialog + RESET)
  
  print()
  
  print(CYAN + "-" * 45 + RESET)
  
  print(f"{BOLD}{YELLOW}Name: {player.name}")
  print(f"Biome: {player.biome}")
  print(f"Happiness: {player.happiness}")
  print(f"Population: {player.population}")
  print(f"Army: {player.army}")
  print(f"Food: {player.food}")
  print(f"Tax: {player.tax}")
  print(f"Day: {player.day}")
  print(f"GDP: {player.gdp}")
  print(f"Gold: {player.gold}")
  print(f"Iorn: {player.iron}")
  print(f"land capacity: {player.land_capacity}")
  print(f"Army atk: {player.army_atk}")
  print(f"Army hp: {player.army_hp}")
  print(f"Army st: {player.army_st}{RESET}")
  
  print(CYAN + "-" * 45)