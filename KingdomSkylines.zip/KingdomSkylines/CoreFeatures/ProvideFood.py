from BaseDatas.Config import *

# ================================PROVIDE FOOD====================================

def provide_food(player):
  
  print(f"{YELLOW}=====================FOOD========================={RESET}")
  print(f"{PURPLE}Population: {player.population}")
  print(f"Food storage: {player.food}{RESET}")
  
  if player.food < player.population:
    print(f"{CYAN}My king!! Our kingdom is lacking food{RESET}")
    print(f"{BG_RED}If happines drops so will population..{RESET}")
    
    player.population -= 20
    player.army -= 20
    player.save_data()
    
    print(f"{BG_RED}Please arrange food 40 of our people has left us{RESET}")
    
  else:
    print(f"{BG_GREEN}Our people's look full my king{RESET}")
    player.food -= player.population
    player.save_data()
    player.level_up()
    print(f"Left food: {player.food}")