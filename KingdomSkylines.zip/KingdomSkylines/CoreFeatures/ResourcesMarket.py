from BaseDatas.Config import *
from BaseDatas.Assets import *

# ==============================RESOURCE MARKET================================

def resource_market(player):
  """resource_market - manages resource market logic"""
  
  clear()
  
  dr = dialogues_resource_market
  
  draw_border("RESOURCE MARKET")
  
  print()
  
  diallog_resource_market = random.choice(dr)
  
  speak("Resource man:" + GREEN + diallog_resource_market + RESET)
  
  print()
  
  print(CYAN + "-" * 45 + RESET)
  
  
  print(f"{BG_CYAN}1) 5 Iron: +100 GDP")
  print(f"2) 5 Gold: +250 GDP{RESET}")
  

  while True:
    resource_choice = input(f"{YELLOW}Enter your choice (1- 2){RESET}: ")
    
    if resource_choice == "1":
      while player.iron >= 5:
        player.iron -= 5
        player.gdp += 100
        player.save_data()
        
        print(f"{BG_GREEN}Successfully sold resource and gained + 100{RESET}")
      else:
        print(f"{BG_RED}Insufficient resource{RESET}")
        break
    elif resource_choice == "2":
      while player.gold >= 5:
        player.gold -= 5
        player.gdp += 250
        player.save_data()
          
        print(f"{BG_GREEN}Successfully sold resource and gained + 250{RESET}")
      else:
        print(f"{BG_RED}Insufficient resource{RESET}")
        break
    else:
      print(f"{BG_RED}Invalid choice{RESET}")
    
# ===================================END=================================