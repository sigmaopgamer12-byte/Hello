from BaseDatas.Config import *
from BaseDatas.Assets import *

# ==================================VIEW LAND===============================

def view_land(player):
  clear()
  
  dp = dialogues_view_land
  
  remaining_land = player.land_capacity - player.population
  
  draw_border("VIEW LAND")
  
  
  print()
  
  dialog_view_land = random.choice([dp[0], dp[1], dp[2], dp[3], dp[4]])
  
  speak("Land viewer: " + GREEN + dialog_view_land + RESET)
  
  print()
  
  print(CYAN + "-" * 45 + RESET)
  
  print(f"{BOLD}{YELLOW}KINGDOM: {player.name}")
  print(f"We currently house {player.population} souls.")
  print(f"Our territory can support up to {player.land_capacity} people.")
  print(f"That leaves us with {remaining_land} open places for new settlers.")
  print(f"Shall we welcome more people or focus on expansion?{RESET}")
  
  print(CYAN + "-" * 45 + RESET)
  
# =====================================END=====================================