from Classes.Kingdom import kingdom
from BaseDatas.DataManager import DataManager
from BaseDatas.Config import *
from BaseDatas.Assets import create_character, load_character, create_biome, load_biome
from Classes.ChildClasses.ArmyType.ShadowCorpse import shadowcorpse
from Classes.ChildClasses.ArmyType.SpellWeavers import spellweavers
from Classes.ChildClasses.ArmyType.Vanguard import vanguard
from Classes.ChildClasses.LandType.Desert import desert
from Classes.ChildClasses.LandType.Mountain import mountain
from Classes.ChildClasses.LandType.Plain import plain
from CoreFeatures.ProfileShow import profile_show
from CoreFeatures.FoodShop import food_shop
from CoreFeatures.ResourcesMarket import resource_market
from CoreFeatures.MotivateArmy import motivate_army
from CoreFeatures.CollectTax import collect_tax
from CoreFeatures.ProvideFood import provide_food
from CoreFeatures.ViewLand import view_land
from CoreFeatures.BuyLand import buy_land
from CoreFeatures.CountryWar import country_war
from CoreFeatures.Dungeon import dungeon_system
from CoreFeatures.NaturalDisasters import disaster_roll

# =====================================MAIN=====================================

def Main():
  """main program"""
  
  global player_main
  
  data_manager = DataManager()
  data = data_manager.load()
  
  print(CYAN, end = "")
  
  username = input("Name your kingdom: ").strip().lower()
  
  biome_from_data = "None"
  army_from_data = "None"
  
  if not username:
    print(f"{BG_RED}Kingdom name cant be empty{RESET}")
    
  if username in data:
 
    biome_from_data = data[username]["biome"]
    army_from_data = data[username]["army_ty"]
    
    print(f"{BG_YELLOW}Welcome back king!!, to your {username}{RESET}")
    
    player_main = load_character(data_manager, username, biome_from_data)
    player_biome = load_biome(data_manager, username, army_from_data)
    
  else:
    print(f"{YELLOW}Creating new character named {username}{RESET}")
    print(f"{GREEN}Choose one of the army type below: {RESET}")
    print(f"{PURPLE}1) ShadowCorpse")
    print("2) SpellWeavers")
    print(f"3) Vanguard{RESET}")
    
    while True:
      
      choice = input(f"{GREEN}Enter your choice: {RESET}").strip()
      
      
      if choice in ["1", "2", "3"]:
 
        player_main = create_character(data_manager, username, biome_from_data, choice)
        print(f"{GREEN}Welcome!!! King the ruler of {player_main.army_ty}{RESET}")
        break
      else:
        print(f"{RED}Invalid choice{RESET}")
        
    print(f"{GREEN}Choose one of the biome type below: {RESET}")
    print(f"{PURPLE}1) Plain")
    print("2) Desert")
    print(f"3) Mountain{RESET}")
    
    while True:
      choice = input(f"{GREEN}Enter your choice: {RESET}").strip()
      
      army_from_data = player_main.army_ty
      
      if choice in ["1", "2", "3"]:
        player_biome = create_biome(data_manager, username, army_from_data, choice)
        print(f"{GREEN}Welcome!!! King the ruler of {player_main.biome}{RESET}")
        break
      else:
        print(f"{RED}Invalid choice{RESET}")
        
  while True:
    
    # disaster
    occurence_disaster = disaster_roll()
    
    print("\n" + "=" * 60)
    print(f"{BG_GREEN}=========MENU========={RESET}")
    print("\n" + "=" * 60)
    
    print("Choose one of the options bellow: ")
    print(f"{BG_MAGENTA}A -> Status")
    print("B -> Market")
    print("C -> Army")
    print("D -> Tax")
    print("E -> Food")
    print("F -> Land")
    print("G -> Invasions")
    print(f"H -> Exit{RESET}")
    
    section_choice = input("Enter your choice(A - G): ").strip()
    
    if section_choice == "A":
      print(f"{BG_YELLOW}1 -> Show kingdom status{RESET}")
      
      task_choice = input("Enter your choice(1): ").strip()
      
      if task_choice == "1":
        profile_show(player_main)
      
    elif section_choice == "B":
      print(f"{BG_YELLOW}2 -> Food market")
      print(f"3 -> Resource market{RESET}")
      
      task_choice = input("Enter your choice(2 - 3): ").strip()
      if task_choice == "2":
        food_shop(player_main)
        player_biome.disaster(occurence_disaster)
        
      elif task_choice == "3":
        resource_market(player_main)
        player_biome.disaster(occurence_disaster)
        
    elif section_choice == "C":
      print(f"{BG_YELLOW}4 -> Motivate army{RESET}")
      
      task_choice = input("Enter your choice(1): ").strip()
      
      if task_choice == "4":
        motivate_army(player_main)
        player_biome.disaster(occurence_disaster)
        
    elif section_choice == "D":
      print(f"{BG_YELLOW}5 -> Collect tax{RESET}")
      
      task_choice = input("Enter your choice(1): ").strip()
      
      if task_choice == "5":
        collect_tax(player_main)
        player_biome.disaster(occurence_disaster)
    
    elif section_choice == "E":
      print(f"{BG_YELLOW}6 -> Provide food{RESET}")
      
      task_choice = input("Enter your choice(1): ").strip()
      
      if task_choice == "6":
        provide_food(player_main)
        player_biome.disaster(occurence_disaster)
        
    elif section_choice == "F":
      print(f"{BG_YELLOW}7 -> View land")
      print(f"8 -> Buy land{RESET}")
      
      task_choice = input("Enter your choice(7 - 8): ").strip()
      
      if task_choice == "7":
        view_land(player_main)
        player_biome.disaster(occurence_disaster)
        
      elif task_choice == "8":
        buy_land(player_main)
        player_biome.disaster(occurence_disaster)
        
    elif section_choice == "G":
      print(f"{BG_YELLOW}9 -> Country war")
      print(f"10 -> Dungeon{RESET}")
      
      task_choice = input("Enter your choice(9 - 10): ").strip()
      
      if task_choice == "9":
        country_war(player_main)
      elif task_choice == "10":
        dungeon_system(player_main)
        
    elif section_choice  == "H":
      print(f"{BG_GREEN}Bye!!, My king cya again{RESET}")
      break
    
    else:
      print(f"{BG_RED}Invaid chocie{RESET}")
      
# ===================================EXECUTION============================

if __name__ == "__main__":
  Main()